Recorded local order-extraction demo, November 1, 2026.
Open before/report.html and after/report.html to inspect the saved results.
Each directory includes the full report.json and the recorded resolved config.json.
order-questions.json contains all six full prompts, expected answers and scorers.
Viewing these files sends no inference requests. The HTML was rendered from the
saved reports; the README screenshots come from the original product recording.
Only the personal hostname and JSON whitespace differ from the source reports.
The eight-second limit and sample orders are illustrative, not a customer SLO.
Ollama parallelism changed from one to four; model, prompts and limits stayed fixed.
Full provenance and limitations: docs/samples/README.md#order-extraction-under-load.
